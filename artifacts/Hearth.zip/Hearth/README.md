# Hearth

ChatGPT-style chat for the Ollama models on your computer.

## Run

Unzip, open a terminal in the `Hearth` folder, then:

```bash
./run.sh
```

If the system says permission denied:

```bash
chmod +x run.sh
./run.sh
```

The first run installs packages. When it is ready, open http://127.0.0.1:8080

Start Ollama with the models you already downloaded, then pick a model in Hearth. Switch models from the dropdown at the top of a chat.

You need Node.js 22 or newer.
