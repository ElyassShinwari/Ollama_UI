import { createFileRoute } from "@tanstack/react-router";
import { listOllamaModels, listXaiModels } from "@/lib/llm/providers.server";

export const Route = createFileRoute("/api/models")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const host = url.searchParams.get("host") || "http://127.0.0.1:11434";

        const [ollama, xai] = await Promise.all([
          listOllamaModels(host)
            .then((models) => ({ ok: true as const, models }))
            .catch((err: unknown) => ({
              ok: false as const,
              models: [] as Awaited<ReturnType<typeof listOllamaModels>>,
              error: err instanceof Error ? err.message : "Ollama unreachable",
            })),
          listXaiModels(),
        ]);

        return Response.json({
          models: [...ollama.models, ...xai],
          ollama: ollama.ok,
          xai: xai.length > 0,
          error: ollama.ok ? undefined : ollama.error,
        });
      },
    },
  },
});
