import { Check, Copy, RotateCcw } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MessageMarkdown } from "@/components/chat/markdown";
import { cn } from "@/lib/utils";
import type { Message } from "@/lib/chat/types";

export function MessageBubble({
  message,
  streaming,
  showRegen,
  onRegenerate,
}: {
  message: Message;
  streaming?: boolean;
  showRegen?: boolean;
  onRegenerate?: () => void;
}) {
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div className="max-w-[min(100%,42rem)] rounded-3xl bg-secondary px-5 py-3 text-[15px] leading-7 whitespace-pre-wrap">
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="group flex flex-col gap-2">
      <div className="flex gap-3">
        <div
          className="mt-1 flex size-7 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground"
          aria-hidden="true"
        >
          <svg viewBox="0 0 24 24" className="size-4">
            <path
              fill="currentColor"
              d="M12 4.5c2.7 3.4 4.8 5.6 4.8 8.4A4.8 4.8 0 1 1 7.2 12.9c0-2.8 2.1-5 4.8-8.4z"
            />
          </svg>
        </div>
        <div className="min-w-0 flex-1 pt-0.5 text-[15px] leading-7">
          {message.content ? (
            <MessageMarkdown content={message.content} />
          ) : (
            <span className="inline-flex items-center gap-2 text-muted-foreground">
              <span className="size-2 animate-pulse rounded-full bg-foreground" />
              Thinking
            </span>
          )}
          {streaming && message.content ? (
            <span className="ml-0.5 inline-block h-4 w-1.5 translate-y-0.5 animate-pulse bg-foreground align-middle" />
          ) : null}
        </div>
      </div>
      <div
        className={cn(
          "ml-10 flex items-center gap-0.5",
          streaming ? "opacity-0" : "opacity-100 md:opacity-0 md:group-hover:opacity-100",
        )}
      >
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label="Copy"
          onClick={async () => {
            await navigator.clipboard.writeText(message.content);
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1400);
          }}
        >
          {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
        </Button>
        {showRegen && onRegenerate ? (
          <Button size="icon-sm" variant="ghost" aria-label="Regenerate" onClick={onRegenerate}>
            <RotateCcw className="size-4" />
          </Button>
        ) : null}
      </div>
    </div>
  );
}
