import { useState } from "react";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { Button, type ButtonProps } from "@/components/ui/button";
import { downloadHearthZip } from "@/lib/download-app";

export function DownloadAppButton({
  label = "Download Hearth",
  ...props
}: Omit<ButtonProps, "onClick"> & { label?: string }) {
  const [busy, setBusy] = useState(false);
  return (
    <Button
      {...props}
      disabled={busy || props.disabled}
      onClick={async () => {
        setBusy(true);
        try {
          await downloadHearthZip();
          toast.success("Saving Hearth.zip");
        } catch {
          toast.error("Could not download. Try again in a moment.");
        } finally {
          setBusy(false);
        }
      }}
    >
      <Download className="size-4" />
      {busy ? "Saving…" : label}
    </Button>
  );
}
