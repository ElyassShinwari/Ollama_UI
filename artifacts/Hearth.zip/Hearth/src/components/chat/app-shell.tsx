import { useCallback, useEffect, useState } from "react";
import { toast, Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { ChatView } from "@/components/chat/chat-view";
import { ConnectScreen } from "@/components/chat/connect-screen";
import { SettingsDialog } from "@/components/chat/settings-dialog";
import { FlameMark, Sidebar } from "@/components/chat/sidebar";
import { fetchCatalog, probeBrowserOllama } from "@/lib/llm/catalog";
import { useChatStore } from "@/lib/chat/store";
import type { ModelCatalog, ModelRef } from "@/lib/chat/types";
import { cn } from "@/lib/utils";

const emptyCatalog: ModelCatalog = {
  models: [],
  status: {
    loading: true,
    ollamaBrowser: false,
    ollamaServer: false,
    xai: false,
  },
};

export function ChatApp() {
  const selectedModel = useChatStore((s) => s.selectedModel);
  const setSelectedModel = useChatStore((s) => s.setSelectedModel);
  const settings = useChatStore((s) => s.settings);
  const setSettings = useChatStore((s) => s.setSettings);
  const sidebarCollapsed = useChatStore((s) => s.sidebarCollapsed);
  const setSidebarCollapsed = useChatStore((s) => s.setSidebarCollapsed);
  const newChat = useChatStore((s) => s.newChat);
  const [catalog, setCatalog] = useState<ModelCatalog>(emptyCatalog);
  const [browserModels, setBrowserModels] = useState<ModelRef[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(() => useChatStore.persist.hasHydrated());

  const refresh = useCallback(async (localModels = browserModels) => {
    setCatalog((c) =>
      c.models.length > 0 ? c : { ...c, status: { ...c.status, loading: true } },
    );
    const next = await fetchCatalog(useChatStore.getState().settings.ollamaHost, localModels);
    setCatalog(next);
    const current = useChatStore.getState().selectedModel;
    if (current) {
      const match = next.models.find(
        (m) => m.id === current.id && m.provider === current.provider,
      );
      if (match) setSelectedModel(match);
    }
  }, [browserModels, setSelectedModel]);

  useEffect(() => {
    const unsub = useChatStore.persist.onFinishHydration(() => setHydrated(true));
    if (useChatStore.persist.hasHydrated()) setHydrated(true);
    return unsub;
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    void refresh();
    const id = window.setInterval(() => void refresh(), 30000);
    return () => window.clearInterval(id);
  }, [refresh, settings.ollamaHost, hydrated]);

  function chooseModel(model: ModelRef) {
    setSelectedModel(model);
    const state = useChatStore.getState();
    if (!state.activeId) state.newChat();
  }

  async function scanThisComputer() {
    const host = useChatStore.getState().settings.ollamaHost;
    const found = await probeBrowserOllama(host);
    setBrowserModels(found);
    await refresh(found);
    if (found.length === 0) {
      toast.error("No Ollama models on this computer yet");
    } else {
      toast.success(`Found ${found.length} local model${found.length === 1 ? "" : "s"}`);
    }
  }

  const sidebar = (
    <Sidebar
      className="h-full w-full"
      onNewChat={() => {
        newChat();
        setMobileOpen(false);
      }}
      onOpenSettings={() => {
        setSettingsOpen(true);
        setMobileOpen(false);
      }}
      onNavigate={() => setMobileOpen(false)}
    />
  );

  if (!hydrated) {
    return (
      <div className="flex h-dvh items-center justify-center bg-background text-foreground">
        <FlameMark className="size-10" />
      </div>
    );
  }

  return (
    <TooltipProvider delayDuration={250}>
      <div className="flex h-dvh overflow-hidden bg-background text-foreground">
        <div
          className={cn(
            "hidden h-full shrink-0 overflow-hidden border-r border-border transition-[width] duration-200 ease-out md:block",
            sidebarCollapsed ? "w-0 border-r-0" : "w-72",
          )}
        >
          <div className="h-full w-72">{sidebar}</div>
        </div>

        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent side="left" className="p-0">
            <SheetTitle className="sr-only">Conversations</SheetTitle>
            {sidebar}
          </SheetContent>
        </Sheet>

        <main className="flex min-w-0 flex-1 flex-col">
          {selectedModel ? (
            <ChatView
              models={catalog.models}
              onOpenSidebar={() => setMobileOpen(true)}
              onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
            />
          ) : (
            <ConnectScreen
              catalog={catalog}
              host={settings.ollamaHost}
              onHostCommit={(host) => {
                setSettings({ ollamaHost: host });
              }}
              onRefresh={() => void refresh()}
              onScanLocal={() => void scanThisComputer()}
              onChoose={chooseModel}
            />
          )}
        </main>
      </div>
      <SettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        onHostChange={() => void refresh()}
      />
      <Toaster theme="dark" position="top-center" />
    </TooltipProvider>
  );
}
