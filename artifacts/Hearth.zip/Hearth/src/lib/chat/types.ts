export type Provider = "ollama" | "xai";
export type Transport = "browser" | "server";

export type ModelRef = {
  id: string;
  name: string;
  provider: Provider;
  transport: Transport;
  size?: number;
  family?: string;
  parameterSize?: string;
};

export type Role = "user" | "assistant" | "system";

export type Message = {
  id: string;
  role: Role;
  content: string;
  modelId?: string;
  createdAt: number;
};

export type Conversation = {
  id: string;
  title: string;
  model: ModelRef;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
  pinned?: boolean;
};

export type Settings = {
  ollamaHost: string;
  temperature: number;
  systemPrompt: string;
};

export type CatalogStatus = {
  loading: boolean;
  ollamaBrowser: boolean;
  ollamaServer: boolean;
  xai: boolean;
  error?: string;
};

export type ModelCatalog = {
  models: ModelRef[];
  status: CatalogStatus;
};
