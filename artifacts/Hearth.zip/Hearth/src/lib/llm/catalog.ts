import type { ModelCatalog, ModelRef } from "@/lib/chat/types";

type ServerCatalog = {
  models: ModelRef[];
  ollama: boolean;
  xai: boolean;
  error?: string;
};

export async function probeBrowserOllama(host: string): Promise<ModelRef[]> {
  try {
    const res = await fetch(`${host.replace(/\/+$/, "")}/api/tags`, {
      signal: AbortSignal.timeout(2500),
    });
    if (!res.ok) return [];
    const body = (await res.json()) as {
      models?: {
        name: string;
        size?: number;
        details?: { family?: string; parameter_size?: string };
      }[];
    };
    return (body.models ?? []).map((m) => ({
      id: m.name,
      name: m.name,
      provider: "ollama" as const,
      transport: "browser" as const,
      size: m.size,
      family: m.details?.family,
      parameterSize: m.details?.parameter_size,
    }));
  } catch {
    return [];
  }
}

function mergeModels(browser: ModelRef[], server: ModelRef[]): ModelRef[] {
  const out: ModelRef[] = [];
  const seen = new Set<string>();
  for (const model of [...browser, ...server]) {
    const key = `${model.provider}:${model.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(model);
  }
  return out;
}

export async function fetchCatalog(host: string, browserModels: ModelRef[] = []): Promise<ModelCatalog> {
  const serverRes = await fetch(`/api/models?host=${encodeURIComponent(host)}`)
    .then(async (r) => {
      if (!r.ok) {
        return {
          models: [],
          ollama: false,
          xai: false,
          error: `Catalog ${r.status}`,
        } satisfies ServerCatalog;
      }
      return (await r.json()) as ServerCatalog;
    })
    .catch(
      () =>
        ({
          models: [],
          ollama: false,
          xai: false,
          error: "Could not reach the model catalog",
        }) satisfies ServerCatalog,
    );

  return {
    models: mergeModels(browserModels, serverRes.models ?? []),
    status: {
      loading: false,
      ollamaBrowser: browserModels.length > 0,
      ollamaServer: Boolean(serverRes.ollama),
      xai: Boolean(serverRes.xai),
      error: serverRes.error,
    },
  };
}

export type ChatRequestBody = {
  provider: "ollama" | "xai";
  transport: "browser" | "server";
  host: string;
  model: string;
  messages: { role: string; content: string }[];
  temperature: number;
  systemPrompt?: string;
};

function withSystem(
  messages: { role: string; content: string }[],
  systemPrompt?: string,
) {
  if (!systemPrompt?.trim()) return messages;
  return [{ role: "system", content: systemPrompt.trim() }, ...messages];
}

export async function streamChat(
  body: ChatRequestBody,
  onDelta: (text: string) => void,
  signal: AbortSignal,
) {
  const messages = withSystem(body.messages, body.systemPrompt).slice(-41);

  if (body.provider === "ollama" && body.transport === "browser") {
    await streamOllamaBrowser(
      { host: body.host, model: body.model, messages, temperature: body.temperature },
      onDelta,
      signal,
    );
    return;
  }

  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      provider: body.provider,
      host: body.host,
      model: body.model,
      messages,
      temperature: body.temperature,
    }),
    signal,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Chat failed (${res.status})`);
  }
  await readSseStream(res, onDelta);
}

async function streamOllamaBrowser(
  opts: {
    host: string;
    model: string;
    messages: { role: string; content: string }[];
    temperature: number;
  },
  onDelta: (text: string) => void,
  signal: AbortSignal,
) {
  const host = opts.host.replace(/\/+$/, "");
  const res = await fetch(`${host}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: opts.model,
      messages: opts.messages,
      stream: true,
      options: { temperature: opts.temperature },
    }),
    signal,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Ollama error ${res.status}`);
  }
  if (!res.body) throw new Error("Ollama returned an empty stream");
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const json = JSON.parse(line) as { message?: { content?: string }; error?: string };
        if (json.error) throw new Error(json.error);
        if (json.message?.content) onDelta(json.message.content);
      } catch (err) {
        if (err instanceof SyntaxError) continue;
        throw err;
      }
    }
  }
}

async function readSseStream(res: Response, onDelta: (text: string) => void) {
  if (!res.body) throw new Error("Empty response");
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const data = trimmed.slice(5).trim();
      if (!data) continue;
      try {
        const json = JSON.parse(data) as { content?: string; error?: string; done?: boolean };
        if (json.error) throw new Error(json.error);
        if (json.content) onDelta(json.content);
      } catch (err) {
        if (err instanceof SyntaxError) continue;
        throw err;
      }
    }
  }
}
