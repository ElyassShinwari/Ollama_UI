import { sanitizeOllamaHost } from "@/lib/utils";
import type { ModelRef } from "@/lib/chat/types";

type OllamaTag = {
  name: string;
  size?: number;
  details?: {
    family?: string;
    parameter_size?: string;
  };
};

type XaiModel = {
  id: string;
  object?: string;
};

function isChatXaiModel(id: string) {
  const lower = id.toLowerCase();
  if (!lower.startsWith("grok")) return false;
  if (
    lower.includes("imagine") ||
    lower.includes("image") ||
    lower.includes("tts") ||
    lower.includes("video") ||
    lower.includes("embedding") ||
    lower.includes("whisper") ||
    lower.includes("build") ||
    lower.includes("multi-agent")
  ) {
    return false;
  }
  if (/\d{4}/.test(lower)) return false;
  return true;
}

function displayXaiName(id: string) {
  if (id === "grok-4.5") return "Grok 4.5";
  return id
    .replace(/^grok-/, "Grok ")
    .replace(/-/g, " ")
    .replace(/\bmini\b/i, "Mini");
}

export async function listOllamaModels(hostRaw: string): Promise<ModelRef[]> {
  const host = sanitizeOllamaHost(hostRaw);
  const res = await fetch(`${host}/api/tags`, {
    signal: AbortSignal.timeout(400),
  });
  if (!res.ok) {
    throw new Error(`Ollama returned ${res.status}`);
  }
  const body = (await res.json()) as { models?: OllamaTag[] };
  return (body.models ?? []).map((m) => ({
    id: m.name,
    name: m.name,
    provider: "ollama" as const,
    transport: "server" as const,
    size: m.size,
    family: m.details?.family,
    parameterSize: m.details?.parameter_size,
  }));
}

export async function listXaiModels(): Promise<ModelRef[]> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return [];
  try {
    const res = await fetch("https://api.x.ai/v1/models", {
      headers: { Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) {
      return [
        {
          id: "grok-4.5",
          name: "Grok 4.5",
          provider: "xai",
          transport: "server",
        },
      ];
    }
    const body = (await res.json()) as { data?: XaiModel[] };
    const models = (body.data ?? [])
      .map((m) => m.id)
      .filter(isChatXaiModel)
      .map(
        (id): ModelRef => ({
          id,
          name: displayXaiName(id),
          provider: "xai",
          transport: "server",
        }),
      );
    if (models.length === 0) {
      return [
        {
          id: "grok-4.5",
          name: "Grok 4.5",
          provider: "xai",
          transport: "server",
        },
      ];
    }
    const preferred = ["grok-4.5", "grok-4", "grok-3"];
    models.sort((a, b) => {
      const ai = preferred.indexOf(a.id);
      const bi = preferred.indexOf(b.id);
      if (ai === -1 && bi === -1) return a.name.localeCompare(b.name);
      if (ai === -1) return 1;
      if (bi === -1) return -1;
      return ai - bi;
    });
    return models;
  } catch {
    return [
      {
        id: "grok-4.5",
        name: "Grok 4.5",
        provider: "xai",
        transport: "server",
      },
    ];
  }
}

export async function* streamOllamaChat(opts: {
  host: string;
  model: string;
  messages: { role: string; content: string }[];
  temperature: number;
  signal: AbortSignal;
}): AsyncGenerator<string> {
  const host = sanitizeOllamaHost(opts.host);
  const res = await fetch(`${host}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: opts.model,
      messages: opts.messages,
      stream: true,
      options: { temperature: opts.temperature },
    }),
    signal: opts.signal,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Ollama error ${res.status}`);
  }
  if (!res.body) throw new Error("Ollama returned an empty stream");
  yield* readNdjson(res.body, (json) => {
    const piece = (json as { message?: { content?: string } }).message?.content;
    return piece ?? "";
  });
}

export async function* streamXaiChat(opts: {
  model: string;
  messages: { role: string; content: string }[];
  temperature: number;
  signal: AbortSignal;
}): AsyncGenerator<string> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) throw new Error("Cloud models are not available in this environment");
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: opts.model,
      messages: opts.messages,
      temperature: opts.temperature,
      stream: true,
      max_tokens: 4096,
    }),
    signal: opts.signal,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `xAI error ${res.status}`);
  }
  if (!res.body) throw new Error("xAI returned an empty stream");
  yield* readSse(res.body, (data) => {
    if (data === "[DONE]") return null;
    try {
      const json = JSON.parse(data) as {
        choices?: { delta?: { content?: string } }[];
      };
      return json.choices?.[0]?.delta?.content ?? "";
    } catch {
      return "";
    }
  });
}

async function* readNdjson(
  body: ReadableStream<Uint8Array>,
  pick: (json: unknown) => string,
): AsyncGenerator<string> {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const piece = pick(JSON.parse(line));
        if (piece) yield piece;
      } catch {
        /* skip malformed */
      }
    }
  }
}

async function* readSse(
  body: ReadableStream<Uint8Array>,
  pick: (data: string) => string | null,
): AsyncGenerator<string> {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const data = trimmed.slice(5).trim();
      const piece = pick(data);
      if (piece === null) return;
      if (piece) yield piece;
    }
  }
}
