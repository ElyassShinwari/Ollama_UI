#!/bin/sh
set -eu
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Hearth needs Node.js 22 or newer (with npm)."
  echo "Install it from https://nodejs.org then run: ./run.sh"
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "Installing Hearth…"
  npm install
fi

echo "Starting Hearth at http://127.0.0.1:8080"
echo "Leave this terminal open. Open that address in your browser."
echo "In Hearth, pick an Ollama model (or set the host in Settings)."
exec npm run dev
